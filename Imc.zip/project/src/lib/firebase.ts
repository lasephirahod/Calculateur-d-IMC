import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getAnalytics } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: "AIzaSyCOgoTR5Wbr9_q0pspsh9XP7F_fQdGaYK4",
  authDomain: "calculateur-d-imc.firebaseapp.com",
  projectId: "calculateur-d-imc",
  storageBucket: "calculateur-d-imc.firebasestorage.app",
  messagingSenderId: "775814867961",
  appId: "1:775814867961:web:332ce9409c432239232b28",
  measurementId: "G-1B2NC8GHV0"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const analytics = getAnalytics(app);