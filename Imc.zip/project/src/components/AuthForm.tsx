import React, { useState } from 'react';
import { Mail, Lock, KeyRound, Loader2, Eye, EyeOff } from 'lucide-react';
import { auth } from '../lib/firebase';
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword,
  sendPasswordResetEmail 
} from 'firebase/auth';
import toast from 'react-hot-toast';

interface AuthFormProps {
  onLogin: () => void;
}

export function AuthForm({ onLogin }: AuthFormProps) {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [resetMode, setResetMode] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [attempts, setAttempts] = useState(0);

  const validatePassword = (password: string) => {
    if (password.length < 6) {
      return "Le mot de passe doit contenir au moins 6 caractères";
    }
    return null;
  };

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return "Veuillez entrer une adresse e-mail valide";
    }
    return null;
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    
    const emailError = validateEmail(email);
    if (emailError) {
      toast.error(emailError);
      return;
    }

    if (!resetMode) {
      const passwordError = validatePassword(password);
      if (passwordError) {
        toast.error(passwordError);
        return;
      }
    }

    setLoading(true);

    try {
      if (resetMode) {
        await sendPasswordResetEmail(auth, email);
        toast.success('Instructions de réinitialisation envoyées par e-mail');
        setResetMode(false);
      } else if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
        setAttempts(0);
        onLogin();
        toast.success('Connexion réussie');
      } else {
        await createUserWithEmailAndPassword(auth, email, password);
        toast.success('Compte créé avec succès');
      }
    } catch (error) {
      let message = "Une erreur s'est produite";
      if (error.code === 'auth/invalid-credential') {
        setAttempts(prev => prev + 1);
        message = attempts >= 2 
          ? 'Plusieurs tentatives échouées. Voulez-vous réinitialiser votre mot de passe ?'
          : 'E-mail ou mot de passe incorrect';
      } else if (error.code === 'auth/email-already-in-use') {
        message = 'Un compte existe déjà avec cet e-mail';
      }
      
      toast.error(message, {
        duration: 5000,
        action: attempts >= 2 && !resetMode ? {
          label: 'Réinitialiser',
          onClick: () => setResetMode(true),
        } : undefined,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFormSwitch = () => {
    setIsLogin(!isLogin);
    setEmail('');
    setPassword('');
    setShowPassword(false);
    setAttempts(0);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-violet-900 to-gray-900 flex justify-center items-center p-5">
      <div className="bg-gray-900/70 p-10 rounded-[20px] shadow-xl max-w-[400px] w-full backdrop-blur-sm transition-all duration-500 hover:shadow-2xl border border-violet-500/20">
        <h1 className="text-violet-400 text-3xl font-bold text-center mb-8">
          {resetMode ? 'Réinitialiser le mot de passe' : isLogin ? 'Connexion' : 'Inscription'}
        </h1>

        <form onSubmit={handleAuth} className="space-y-6">
          <div className="relative group">
            <label className="block mb-2 font-bold text-gray-200 group-hover:text-white transition-colors">
              E-mail
            </label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-hover:text-violet-300">
                <Mail size={20} />
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value.trim())}
                className="w-full p-3 pl-12 bg-gray-900/50 border-2 border-violet-500/30 rounded-lg focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-400/30 transition-all duration-300 hover:border-violet-400 text-white"
                placeholder="votre@email.com"
                required
                autoComplete="email"
              />
            </div>
          </div>

          {!resetMode && (
            <div className="relative group">
              <label className="block mb-2 font-bold text-gray-200 group-hover:text-white transition-colors">
                Mot de passe
              </label>
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 group-hover:text-violet-300">
                  <Lock size={20} />
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full p-3 pl-12 pr-12 bg-gray-900/50 border-2 border-violet-500/30 rounded-lg focus:border-violet-400 focus:outline-none focus:ring-2 focus:ring-violet-400/30 transition-all duration-300 hover:border-violet-400 text-white"
                  placeholder="••••••••"
                  required
                  minLength={6}
                  autoComplete={isLogin ? "current-password" : "new-password"}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-violet-300 transition-colors focus:outline-none"
                  aria-label={showPassword ? "Masquer le mot de passe" : "Afficher le mot de passe"}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
              {!isLogin && (
                <p className="mt-2 text-sm text-gray-400">
                  Le mot de passe doit contenir au moins 6 caractères
                </p>
              )}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-gradient-to-r from-violet-600 to-violet-400 text-white py-3 px-6 rounded-full font-bold uppercase tracking-wide shadow-lg transform transition-all duration-300 hover:from-violet-500 hover:to-violet-300 hover:-translate-y-1 hover:shadow-xl flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <Loader2 className="animate-spin" size={20} />
            ) : resetMode ? (
              <KeyRound size={20} />
            ) : (
              <Lock size={20} />
            )}
            {loading
              ? 'Chargement...'
              : resetMode
              ? 'Envoyer les instructions'
              : isLogin
              ? 'Se connecter'
              : "S'inscrire"}
          </button>

          {!resetMode && (
            <button
              type="button"
              onClick={handleFormSwitch}
              className="w-full text-violet-400 hover:text-violet-300 transition-colors"
            >
              {isLogin ? "Pas encore de compte ? S'inscrire" : 'Déjà un compte ? Se connecter'}
            </button>
          )}

          {isLogin && !resetMode && (
            <button
              type="button"
              onClick={() => setResetMode(true)}
              className="w-full text-violet-400 hover:text-violet-300 transition-colors"
            >
              Mot de passe oublié ?
            </button>
          )}

          {resetMode && (
            <button
              type="button"
              onClick={() => {
                setResetMode(false);
                setAttempts(0);
              }}
              className="w-full text-violet-400 hover:text-violet-300 transition-colors"
            >
              Retour à la connexion
            </button>
          )}
        </form>
      </div>
    </div>
  );
}