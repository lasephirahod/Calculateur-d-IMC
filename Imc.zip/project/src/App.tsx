import React, { useState, useEffect } from 'react';
import { Download, Calculator, User, Weight, Ruler, Calendar, Clock, Loader2 } from 'lucide-react';
import { jsPDF } from 'jspdf';
import { Toaster } from 'react-hot-toast';
import { AuthForm } from './components/AuthForm';
import { auth } from './lib/firebase';
import { onAuthStateChanged } from 'firebase/auth';

interface BMIRecord {
  date: string;
  time: string;
  name: string;
  contact: string;
  weight: number;
  height: number;
  bmi: number;
  category: string;
}

interface Recommendations {
  diet: string;
  exercise: string;
}

function BMICalculator() {
  // Le reste du code BMICalculator reste inchangé
  // ... (garder tout le code existant de BMICalculator)
}

function App() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });

    return () => unsubscribe();
  }, []);

  if (!user) {
    return (
      <>
        <AuthForm onLogin={() => {}} />
        <Toaster position="top-right" />
      </>
    );
  }

  return (
    <>
      <BMICalculator />
      <Toaster position="top-right" />
    </>
  );
}

export default App;